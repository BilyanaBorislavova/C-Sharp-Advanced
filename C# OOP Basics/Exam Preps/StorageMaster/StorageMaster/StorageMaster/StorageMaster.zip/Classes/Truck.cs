﻿using StorageMaster.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Classes
{
    class Truck : Vehicle
    {
        public Truck() : base(5)
        {
        }
    }
}
