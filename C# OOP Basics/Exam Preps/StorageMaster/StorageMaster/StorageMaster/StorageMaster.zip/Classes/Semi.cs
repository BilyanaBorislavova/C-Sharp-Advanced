﻿using StorageMaster.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Classes
{
    class Semi : Vehicle
    {
        public Semi() : base(10)
        {
        }
    }
}
